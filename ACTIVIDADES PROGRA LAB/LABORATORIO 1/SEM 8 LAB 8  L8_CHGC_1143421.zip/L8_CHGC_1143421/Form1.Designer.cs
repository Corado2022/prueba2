﻿namespace L8_CHGC_1143421
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.select = new System.Windows.Forms.ComboBox();
            this.sumatoria = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.res_sum = new System.Windows.Forms.Label();
            this.sumar_btn = new System.Windows.Forms.Button();
            this.num_sumatoria = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.res_factorial = new System.Windows.Forms.Label();
            this.select_factorial = new System.Windows.Forms.Button();
            this.num_factorial = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.button1 = new System.Windows.Forms.Button();
            this.error = new System.Windows.Forms.Label();
            this.tablasm = new System.Windows.Forms.RichTextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.num_perfecto = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.button3 = new System.Windows.Forms.Button();
            this.es_perfecto = new System.Windows.Forms.Label();
            this.sumatoria.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(91, 69);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(147, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "Seleccione una opción:";
            // 
            // select
            // 
            this.select.FormattingEnabled = true;
            this.select.Items.AddRange(new object[] {
            "Sumatoria",
            "Factorial",
            "Teblas de Multiplicar",
            "Número Perfecto"});
            this.select.Location = new System.Drawing.Point(94, 101);
            this.select.Name = "select";
            this.select.Size = new System.Drawing.Size(161, 24);
            this.select.TabIndex = 1;
            this.select.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // sumatoria
            // 
            this.sumatoria.Controls.Add(this.tabPage1);
            this.sumatoria.Controls.Add(this.tabPage2);
            this.sumatoria.Controls.Add(this.tabPage3);
            this.sumatoria.Controls.Add(this.tabPage4);
            this.sumatoria.Location = new System.Drawing.Point(299, 34);
            this.sumatoria.Name = "sumatoria";
            this.sumatoria.RightToLeftLayout = true;
            this.sumatoria.SelectedIndex = 0;
            this.sumatoria.Size = new System.Drawing.Size(438, 384);
            this.sumatoria.TabIndex = 2;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.res_sum);
            this.tabPage1.Controls.Add(this.sumar_btn);
            this.tabPage1.Controls.Add(this.num_sumatoria);
            this.tabPage1.Controls.Add(this.label2);
            this.tabPage1.Location = new System.Drawing.Point(4, 25);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(430, 355);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Sumatoria";
            this.tabPage1.UseVisualStyleBackColor = true;
            this.tabPage1.Click += new System.EventHandler(this.tabPage1_Click);
            // 
            // res_sum
            // 
            this.res_sum.AutoSize = true;
            this.res_sum.Location = new System.Drawing.Point(34, 146);
            this.res_sum.Name = "res_sum";
            this.res_sum.Size = new System.Drawing.Size(72, 16);
            this.res_sum.TabIndex = 7;
            this.res_sum.Text = "Resultado:";
            // 
            // sumar_btn
            // 
            this.sumar_btn.Location = new System.Drawing.Point(174, 79);
            this.sumar_btn.Name = "sumar_btn";
            this.sumar_btn.Size = new System.Drawing.Size(112, 28);
            this.sumar_btn.TabIndex = 5;
            this.sumar_btn.Text = "Calcular";
            this.sumar_btn.UseVisualStyleBackColor = true;
            this.sumar_btn.Click += new System.EventHandler(this.sumar_btn_Click);
            // 
            // num_sumatoria
            // 
            this.num_sumatoria.Location = new System.Drawing.Point(37, 85);
            this.num_sumatoria.Name = "num_sumatoria";
            this.num_sumatoria.Size = new System.Drawing.Size(100, 22);
            this.num_sumatoria.TabIndex = 6;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(34, 50);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(120, 16);
            this.label2.TabIndex = 5;
            this.label2.Text = "Ingrese un número:";
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.res_factorial);
            this.tabPage2.Controls.Add(this.select_factorial);
            this.tabPage2.Controls.Add(this.num_factorial);
            this.tabPage2.Controls.Add(this.label4);
            this.tabPage2.Location = new System.Drawing.Point(4, 25);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(430, 355);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Factorial";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // res_factorial
            // 
            this.res_factorial.AutoSize = true;
            this.res_factorial.Location = new System.Drawing.Point(38, 138);
            this.res_factorial.Name = "res_factorial";
            this.res_factorial.Size = new System.Drawing.Size(72, 16);
            this.res_factorial.TabIndex = 11;
            this.res_factorial.Text = "Resultado:";
            // 
            // select_factorial
            // 
            this.select_factorial.Location = new System.Drawing.Point(178, 71);
            this.select_factorial.Name = "select_factorial";
            this.select_factorial.Size = new System.Drawing.Size(112, 28);
            this.select_factorial.TabIndex = 8;
            this.select_factorial.Text = "Calcular";
            this.select_factorial.UseVisualStyleBackColor = true;
            this.select_factorial.Click += new System.EventHandler(this.select_factorial_Click);
            // 
            // num_factorial
            // 
            this.num_factorial.Location = new System.Drawing.Point(41, 77);
            this.num_factorial.Name = "num_factorial";
            this.num_factorial.Size = new System.Drawing.Size(100, 22);
            this.num_factorial.TabIndex = 10;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(38, 42);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(120, 16);
            this.label4.TabIndex = 9;
            this.label4.Text = "Ingrese un número:";
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.button2);
            this.tabPage3.Controls.Add(this.label3);
            this.tabPage3.Controls.Add(this.tablasm);
            this.tabPage3.Location = new System.Drawing.Point(4, 25);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(430, 355);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Tablas de multiplicar";
            this.tabPage3.UseVisualStyleBackColor = true;
            this.tabPage3.Click += new System.EventHandler(this.tabPage3_Click);
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.es_perfecto);
            this.tabPage4.Controls.Add(this.button3);
            this.tabPage4.Controls.Add(this.label5);
            this.tabPage4.Controls.Add(this.num_perfecto);
            this.tabPage4.Location = new System.Drawing.Point(4, 25);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(430, 355);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "Número perfecto";
            this.tabPage4.UseVisualStyleBackColor = true;
            this.tabPage4.Click += new System.EventHandler(this.tabPage4_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(117, 144);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(112, 28);
            this.button1.TabIndex = 3;
            this.button1.Text = "Seleccionar";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // error
            // 
            this.error.AutoSize = true;
            this.error.Location = new System.Drawing.Point(52, 205);
            this.error.Name = "error";
            this.error.Size = new System.Drawing.Size(0, 16);
            this.error.TabIndex = 4;
            // 
            // tablasm
            // 
            this.tablasm.Location = new System.Drawing.Point(6, 70);
            this.tablasm.Name = "tablasm";
            this.tablasm.Size = new System.Drawing.Size(407, 256);
            this.tablasm.TabIndex = 0;
            this.tablasm.Text = "";
            this.tablasm.TextChanged += new System.EventHandler(this.tablasm_TextChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(25, 42);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(180, 16);
            this.label3.TabIndex = 1;
            this.label3.Text = "Presione para mostrar tablas";
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(211, 36);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(112, 28);
            this.button2.TabIndex = 5;
            this.button2.Text = "Mostrar";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // num_perfecto
            // 
            this.num_perfecto.Location = new System.Drawing.Point(36, 85);
            this.num_perfecto.Name = "num_perfecto";
            this.num_perfecto.Size = new System.Drawing.Size(100, 22);
            this.num_perfecto.TabIndex = 7;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(33, 50);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(120, 16);
            this.label5.TabIndex = 5;
            this.label5.Text = "Ingrese un número:";
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(182, 85);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(112, 28);
            this.button3.TabIndex = 5;
            this.button3.Text = "Ingresar";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // es_perfecto
            // 
            this.es_perfecto.AutoSize = true;
            this.es_perfecto.Location = new System.Drawing.Point(33, 146);
            this.es_perfecto.Name = "es_perfecto";
            this.es_perfecto.Size = new System.Drawing.Size(0, 16);
            this.es_perfecto.TabIndex = 8;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.error);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.sumatoria);
            this.Controls.Add(this.select);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.sumatoria.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox select;
        private System.Windows.Forms.TabControl sumatoria;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label error;
        private System.Windows.Forms.Label res_sum;
        private System.Windows.Forms.Button sumar_btn;
        private System.Windows.Forms.TextBox num_sumatoria;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label res_factorial;
        private System.Windows.Forms.Button select_factorial;
        private System.Windows.Forms.TextBox num_factorial;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.RichTextBox tablasm;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label es_perfecto;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox num_perfecto;
    }
}

