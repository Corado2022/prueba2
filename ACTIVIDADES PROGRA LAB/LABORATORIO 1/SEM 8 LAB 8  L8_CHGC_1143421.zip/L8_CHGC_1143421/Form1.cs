﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace L8_CHGC_1143421
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void tabPage1_Click(object sender, EventArgs e)
        {
            
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            int pestaña = 0;
            try
            {
                pestaña = select.SelectedIndex;
            }
            catch 
            {
                error.Text = "Debe escoger una opción"; 
                
            }
            

            switch (pestaña)
            {
                case 1: sumatoria.SelectedIndex = 1;
                    break;
                case 2:
                    sumatoria.SelectedIndex = 2;
                    break;
                case 3:
                    sumatoria.SelectedIndex = 3;
                    

                    break;
                case 4:
                    sumatoria.SelectedIndex = 4;
                    break;
                    
            }
            
        }

        private void tabPage4_Click(object sender, EventArgs e)
        {

        }

        private void sumar_btn_Click(object sender, EventArgs e)
        {
            int num = 0;
            try
            {
                 num = Convert.ToInt32(num_sumatoria.Text);
            }
            catch
            {
                error.Text = "Debe ingresar un número.";
            }

            error.Text = "Nuúmero ingresado exitosamente";
            int sumatoria = 0;
            while (num > 0)
            {
                int i = num;
                sumatoria = sumatoria + i;
                --num;
            }
            res_sum.Text="Resultado: " + sumatoria.ToString();
        }

        private void select_factorial_Click(object sender, EventArgs e)
        {
            int num = 0;
            try
            {
                num = Convert.ToInt32(num_factorial.Text);
            }
            catch
            {
                error.Text = "Debe ingresar un número.";
            }
            error.Text = "Nuúmero ingresado exitosamente";
            int factorial = 1;
            while (num > 0)
            {
                int i = num;
                factorial = factorial*num;
                --num;
            }
            res_factorial.Text = "Resultado: " + factorial.ToString();
        }
        

        private void tablasm_TextChanged(object sender, EventArgs e)
        {

        }

        private void tabPage3_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            int[,] m = new int[10, 10];
            for (int i = 0; i < 10; i++)
            {
                for (int j = 0; j < 10; j++)
                {
                    m[i, j] = (i + 1) * (j + 1);
                }
            }

            string tablas = "";
            for (int i = 0; i < 10; i++)
            {
                for (int j = 0; j < 10; j++)
                {
                    tablas = tablas + m[i, j].ToString() + "\t";
                }
                tablas = tablas + "\n";
            }
            tablasm.Text = tablas;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            int num = 0;
            int b, a,s,j;
            try
            {
                num = Convert.ToInt32(num_perfecto.Text);
            }
            catch
            {
                error.Text = "Debe ingresar un número";
            }

            for (int i = 1; i <= num; i++)
            {
                b = 0;
                s = i / 2;

                for (j = 1; j <= s; j++)
                {

                    a = i % j;

                    if (a == 0)
                        b = b + j;
                }
                if (b == i)
                { 
                    es_perfecto.Text="El numero " + i + " es perfecto.";
                }
                else
                {
                    es_perfecto.Text = "El numero " + i + " no es perfecto.";
                }

            }
            
        }
    }
}

