﻿// See https://aka.ms/new-console-template for more information


//Declaracion de variables
bool ingreso = false, ingreso_cuartos = false, horas = false;
double temperaturas_sumatoria = 0, temp_min = 0, temp_max = 0, temp_actual = 0;
int panel_ingreso, opcion_datos, opcion_calefaccion, opcion_ventilacion, opcion_iluminacion, no_cuartos = 1, hora_encendido = 60, hora_apagado = 60, programa_tempmax = 37, programa_tempmin = 8;
int temperaturas_contador = 0;
DateTime hora_actual = DateTime.Now;
string nombre = "", temperaturas_registradas = "";
int hora = hora_actual.Hour;
//pantalla 1
pantalla1:
Console.ForegroundColor = ConsoleColor.Green;

Console.WriteLine("                Casa automatizada           " + nombre + "              " + hora_actual);
Console.WriteLine();
Console.ForegroundColor = ConsoleColor.Blue;
Console.WriteLine("Panel de control:");
Console.ForegroundColor = ConsoleColor.White;
Console.WriteLine();
Console.WriteLine(" 1. Registro de datos de la casa");
Console.WriteLine(" 2. Control de ventilación");
Console.WriteLine(" 3. Control de calefacción");
Console.WriteLine(" 4. Control de iluminación");
Console.WriteLine(" 5. Ver datos ingresados");
Console.ForegroundColor = ConsoleColor.Red;
Console.WriteLine(" 6. Salir");

Console.WriteLine();

Console.ForegroundColor = ConsoleColor.White;
Console.WriteLine("Ingrese el número de acción que desea realizar. Recuerda llenar el registro antes.");
//Ingreso pantalla uno
ingreso:
Console.ForegroundColor = ConsoleColor.White;

try
{
    panel_ingreso = int.Parse(Console.ReadLine());
}
catch
{
    Console.ForegroundColor = ConsoleColor.Red;
    Console.WriteLine("ERROR. Debe ingresar un número");
    goto ingreso;
}
if (panel_ingreso > 6 || panel_ingreso < 1)
{
    Console.ForegroundColor = ConsoleColor.Red;
    Console.WriteLine("ERROR. Esa opción no existe");
    goto ingreso;
}
if (panel_ingreso != 1 & ingreso == false & panel_ingreso != 6)
{
    Console.ForegroundColor = ConsoleColor.Red;
    Console.WriteLine("ERROR. Debe realizar el registro primero.");
    goto ingreso;
}

switch (panel_ingreso)
{
    case 1:
        Console.Clear();
        goto registro;
    case 2:
        Console.Clear();
        goto ventilacion;
    case 3:
        Console.Clear();
        goto calefaccion;
    case 4:
        Console.Clear();
        goto iluminacion;
    case 5:
        Console.Clear();
        goto registrados;
    case 6:
        Console.Clear();
        goto salida;
}


registro:
Console.ForegroundColor = ConsoleColor.Green;
Console.WriteLine("                Casa automatizada           " + nombre + "              " + hora_actual);
Console.WriteLine();
Console.ForegroundColor = ConsoleColor.Blue;
Console.WriteLine("Ingreso de datos:");
Console.ForegroundColor = ConsoleColor.White;
Console.WriteLine();
Console.WriteLine(" 1. Nombre de la casa");
Console.WriteLine(" 2. Cuartos en la casa");
Console.ForegroundColor = ConsoleColor.Red;
Console.WriteLine(" 3. Regresar al panel de control");

Console.WriteLine();

Console.ForegroundColor = ConsoleColor.White;
Console.WriteLine("Ingrese el número de acción que desea realizar");
opcion_datos:
Console.ForegroundColor = ConsoleColor.White;
try
{
    opcion_datos = int.Parse(Console.ReadLine());
}
catch
{
    Console.ForegroundColor = ConsoleColor.Red;
    Console.WriteLine("ERROR. Debe ingresar un número.");
    goto opcion_datos;
}

if (opcion_datos < 1 || opcion_datos > 3)
{
    Console.ForegroundColor = ConsoleColor.Red;
    Console.WriteLine("ERROR. Esa opción no es valida.");
    goto opcion_datos;
}
if (opcion_datos == 1)
{
    Console.WriteLine("Ingrese nombre de la casa: ");
    nombre = Convert.ToString(Console.ReadLine());
    Console.Clear();
    goto registro;
}

if (opcion_datos == 2)
{
    Console.WriteLine("Ingrese número de cuartos");
ingreso_cuartos:
    Console.ForegroundColor = ConsoleColor.White;
    try
    {
        no_cuartos = int.Parse(Console.ReadLine());
    }
    catch
    {
        Console.ForegroundColor = ConsoleColor.Red;
        Console.WriteLine("ERROR. Debe ingresar un número");
        goto ingreso_cuartos;
    }
    if (no_cuartos < 1)
    {
        Console.ForegroundColor = ConsoleColor.Red;
        Console.WriteLine("ERROR. Esa opción no es valida.");
        goto ingreso_cuartos;
    }

    ingreso_cuartos = true;
    ingreso = true;
    Console.Clear();
    goto registro;
}
if (opcion_datos == 3)
{
    if (ingreso_cuartos == false)
    {
        Console.ForegroundColor = ConsoleColor.Red;
        Console.WriteLine("ERROR. No ha ingresado la cantidad de cuartos.");
        goto opcion_datos;
    }
    else
    {
        Console.Clear();
        goto pantalla1;
    }
}

ventilacion:
Console.Clear();
Console.ForegroundColor = ConsoleColor.Green;
Console.WriteLine("                Casa automatizada           " + nombre + "              " + hora_actual);
Console.WriteLine();
Console.ForegroundColor = ConsoleColor.Blue;
Console.WriteLine("Control de ventilación:");
Console.ForegroundColor = ConsoleColor.White;
Console.WriteLine();
Console.WriteLine(" 1. Hora de encendido");
Console.WriteLine(" 2. Hora de apagado");
Console.ForegroundColor = ConsoleColor.Red;
Console.WriteLine(" 3. Regresar al panel de control");

Console.WriteLine();

Console.ForegroundColor = ConsoleColor.White;
Console.WriteLine("Ingrese el número de acción que desea realizar");
ingreso_ventilacion:
Console.ForegroundColor = ConsoleColor.White;
try
{
    opcion_ventilacion = int.Parse(Console.ReadLine());
}
catch
{
    Console.ForegroundColor = ConsoleColor.Red;
    Console.WriteLine("ERROR.Debe ingresar un número.");
    goto ingreso_ventilacion;
}

if (opcion_ventilacion < 1 || opcion_ventilacion > 3)
{
    Console.ForegroundColor = ConsoleColor.Red;
    Console.WriteLine("ERROR. Esa opción no existe.");
    goto ingreso_ventilacion;
}
if (opcion_ventilacion == 1)
{
ingreso_hora_encendido:
    Console.ForegroundColor = ConsoleColor.White;
    Console.WriteLine("Ingrese hora de encendido");
    try
    {
        hora_encendido = int.Parse(Console.ReadLine());
    }
    catch
    {
        Console.ForegroundColor = ConsoleColor.Red;
        Console.WriteLine("ERROR. Debe ingresar un número");
        goto ingreso_hora_encendido;
    }
    if (hora_encendido < 0 || hora_encendido > 23)
    {
        Console.ForegroundColor = ConsoleColor.Red;
        Console.WriteLine("ERROR. Esa hora no es válida");
        goto ingreso_hora_encendido;
    }

    goto ventilacion;
}

if (opcion_ventilacion == 2)
{
ingreso_hora_apagado:
    Console.ForegroundColor = ConsoleColor.White;
    Console.WriteLine("Ingrese hora de apagado");
    try
    {
        hora_apagado = int.Parse(Console.ReadLine());
    }
    catch
    {
        Console.ForegroundColor = ConsoleColor.Red;
        Console.WriteLine("ERROR. Debe ingresar un número");
        goto ingreso_hora_apagado;
    }
    if (hora_apagado < 0 || hora_apagado > 23)
    {
        Console.ForegroundColor = ConsoleColor.Red;
        Console.WriteLine("ERROR. Esa hora no es válida");
        goto ingreso_hora_apagado;
    }

    goto ventilacion;
}

if (opcion_ventilacion == 3)
{
    if (hora_encendido != 60 & hora_apagado != 60)
    {
        horas = true;
    }
    if (opcion_ventilacion == 3)
    {
        if (horas == true)
        {
            Console.Clear();
            goto pantalla1;
        }
        else
        {
            Console.WriteLine("ERROR. Debe ingresar ambas horas.");
            goto ingreso_ventilacion;
        }
    }
}

calefaccion:
Console.Clear();
Console.ForegroundColor = ConsoleColor.Green;
Console.WriteLine("                Casa automatizada           " + nombre + "              " + hora_actual);
Console.WriteLine();
Console.ForegroundColor = ConsoleColor.Blue;
Console.WriteLine("Control de calefacción:");
Console.ForegroundColor = ConsoleColor.White;
Console.WriteLine();
Console.WriteLine(" 1. Temperatura máxima");
Console.WriteLine(" 2. Temperatura mínima");
Console.WriteLine(" 3. Temperatura actual");
Console.ForegroundColor = ConsoleColor.Red;
Console.WriteLine(" 4. Regresar al panel de control");

Console.WriteLine();

Console.ForegroundColor = ConsoleColor.White;
Console.WriteLine("Ingrese el número del dato que desea ingresar");
ingreso_calefaccion:
Console.ForegroundColor = ConsoleColor.White;
try
{
    opcion_calefaccion = int.Parse(Console.ReadLine());
}
catch
{
    Console.ForegroundColor = ConsoleColor.Red;
    Console.Write("ERROR. Debe ingresar un número.");
    goto ingreso_calefaccion;
}
if (opcion_calefaccion < 1 || opcion_calefaccion > 4)
{
    Console.ForegroundColor = ConsoleColor.Red;
    Console.WriteLine("ERROR. Esa opción no existe.");
    goto ingreso_calefaccion;
}


if (opcion_calefaccion == 1)
{
    Console.WriteLine("Ingrese la temperatura máxima");
temperatura_maxima:
    Console.ForegroundColor = ConsoleColor.White;
    try
    {
        temp_max = int.Parse(Console.ReadLine());
    }
    catch
    {
        Console.ForegroundColor = ConsoleColor.Red;
        Console.WriteLine("ERROR. Debe ingresar un número.");
        goto temperatura_maxima;
    }
    if (temp_max > programa_tempmax || temp_max < programa_tempmin + 1)
    {
        Console.ForegroundColor = ConsoleColor.Red;
        Console.WriteLine("ERROR. Temperatura ingresada no es válida.");
        goto temperatura_maxima;
    }
    else
    {
        goto calefaccion;
    }

}
if (opcion_calefaccion == 2)
{
    Console.WriteLine("Ingrese la temperatura mínima");
temperatura_minima:
    Console.ForegroundColor = ConsoleColor.White;
    try
    {
        temp_min = int.Parse(Console.ReadLine());
    }
    catch
    {
        Console.ForegroundColor = ConsoleColor.Red;
        Console.WriteLine("ERROR. Debe ingresar un número.");
        goto temperatura_minima;
    }
    if (temp_min > programa_tempmax - 1 || temp_min < programa_tempmin)
    {
        Console.ForegroundColor = ConsoleColor.Red;
        Console.WriteLine("ERROR. Temperatura ingresada no es válida.");
        goto temperatura_minima;
    }
    else
    {
        goto calefaccion;
    }

}
if (opcion_calefaccion == 3)
{
    if (temp_max == 0 || temp_min == 0)
    {
        Console.ForegroundColor = ConsoleColor.Red;
        Console.WriteLine("ERROR. Debe ingresar las temperaturas máxima y mínima primero.");

        goto ingreso_calefaccion;
    }
    Console.WriteLine("Ingrese la temperatura que desea tener:");
temperatura_actual:
    Console.ForegroundColor = ConsoleColor.White;
    try
    {
        temp_actual = Convert.ToDouble(Console.ReadLine());
    }
    catch
    {
        Console.ForegroundColor = ConsoleColor.Red;
        Console.WriteLine("ERROR. Debe ingresar un número.");
        goto temperatura_actual;
    }
    if (temp_actual > temp_max || temp_actual < temp_min)
    {
        Console.ForegroundColor = ConsoleColor.Red;
        Console.WriteLine("ERROR. Temperatura ingresada no es válida.");
        goto temperatura_actual;
    }
    temperaturas_registradas = temperaturas_registradas + temp_actual + ", ";
    temperaturas_sumatoria = temperaturas_sumatoria + temp_actual;
    ++temperaturas_contador;
    goto calefaccion;
}
if (opcion_calefaccion == 4)
{
    Console.Clear();
    goto pantalla1;
}



iluminacion:
Console.Clear();
Console.ForegroundColor = ConsoleColor.Green;
Console.WriteLine("                Casa automatizada           " + nombre + "              " + hora_actual);
Console.WriteLine();
Console.ForegroundColor = ConsoleColor.Blue;
Console.WriteLine("Control de iluminación:");
Console.ForegroundColor = ConsoleColor.White;
Console.WriteLine();
Console.WriteLine(" 1. Ingresar/retirar personas en los cuartos");
Console.ForegroundColor = ConsoleColor.Red;
Console.WriteLine(" 2. Regresar al panel de control");

Console.WriteLine();

Console.ForegroundColor = ConsoleColor.White;
Console.WriteLine("Ingrese el número del dato que desea ingresar");
ingreso_iluminacion:
Console.ForegroundColor = ConsoleColor.White;
try
{
    opcion_iluminacion = int.Parse(Console.ReadLine());
}
catch
{
    Console.ForegroundColor = ConsoleColor.Red;
    Console.WriteLine("ERROR. Debe ingresar un número");
    goto ingreso_iluminacion;
}
if (opcion_iluminacion < 1 || opcion_iluminacion > 2)
{
    Console.ForegroundColor = ConsoleColor.Red;
    Console.WriteLine("ERROR. Esa opción no es válida.");
    goto ingreso_iluminacion;
}

int[] v_cuartos = new int[no_cuartos];
string[] v_personas = new string[no_cuartos];
string[] v_iluminacion = new string[no_cuartos];

string iluminación = "";
for (int i = 0; i < no_cuartos; i++)
{
    int contador = 0;
    v_cuartos[i] = ++contador;
}

if (opcion_iluminacion == 1)
{
    int contador = 1;
    for (int i = 0; i < no_cuartos; i++)
    {
        string r;
    entrada:
        Console.ForegroundColor = ConsoleColor.White;
        Console.WriteLine("¿Hay personas en el cuarto no. " + contador + " s = sí n = no");
        try
        {
            r = Convert.ToString(Console.ReadLine());
        }
        catch
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("ERROR. Debe ingresar un número.");
            goto entrada;
        }
        r.ToLower();

        if (r != "s" & r != "n")
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("ERROR. Esa opción no es valida.");
            goto entrada;

        }
        if (r == "s")
        {
            iluminación = iluminación + contador + "\t" + "\t" + "Luces encendidas" + "\n";
        }
        else
        {
            iluminación = iluminación + contador + "\t" + "\t" + "Luces apagadas" + "\n";
        }

        contador++;

    }
    Console.Clear();
    Console.ForegroundColor = ConsoleColor.Blue;
    Console.WriteLine("No. de cuarto" + "\t" + "Estado de iluminación");
    Console.ForegroundColor = ConsoleColor.White;
    Console.WriteLine(iluminación);
    Console.WriteLine("Presiona cualquier tecla para volver al control de iluminación");
    Console.ReadKey();
    goto iluminacion;
}
if (opcion_iluminacion == 2)
{ Console.Clear(); goto pantalla1; }



registrados:
Console.Clear();
string si_no = "";
if (hora_encendido < 23 & hora_apagado >= hora_encendido)
{
    if (hora_encendido >= hora_actual.Hour & hora_apagado > hora_actual.Hour)
    {
        si_no = "Encendida";
    }
    else
    {
        si_no = "Apagada";
    }
}
else
{
    if (hora_encendido <= hora_actual.Hour & hora_apagado < hora_actual.Hour)
    {
        si_no = "Encendida";
    }
    else
    {
        si_no = "Apagada";
    }
}
double promedio = temperaturas_sumatoria / temperaturas_contador;
Console.ForegroundColor = ConsoleColor.Green;
Random aleatorio = new Random();
Console.WriteLine("                Casa automatizada           " + nombre + "              " + hora_actual);
Console.WriteLine();
Console.ForegroundColor = ConsoleColor.Blue;
Console.WriteLine("Registro de datos:");
Console.ForegroundColor = ConsoleColor.White;
Console.WriteLine();
Console.WriteLine(" 1. Nombre de la casa: " + nombre + " Cantidad de cuartos " + no_cuartos);
Console.WriteLine(" 2. Cantidad de humedad: " + aleatorio.Next(40, 70) + "%" + " Estado de ventilación: " + si_no);
Console.WriteLine(" 3. Temperatura máxima: " + temp_max + "° Temperatura mínima: " + temp_min + "°");
Console.WriteLine("    Temperatura actual: " + temp_actual + "° Temperatura promedio: " + promedio + "°");
Console.WriteLine("    Temperaturas registradas : " + temperaturas_registradas);
Console.WriteLine(" 4. Iluminación: Ver en la pestaña de iluminación");
Console.ForegroundColor = ConsoleColor.Red;
Console.WriteLine(" Click en cualquier tecla para volver al menú pincipal.");

Console.ReadKey();
Console.Clear();
goto pantalla1;

salida:
return;
    


